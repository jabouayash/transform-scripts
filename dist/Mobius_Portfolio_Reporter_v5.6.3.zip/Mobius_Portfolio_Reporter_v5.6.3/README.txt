MOBIUS PORTFOLIO REPORTER v5.6.3
================================

To Update:
1. Replace "Portfolio Transformer.xlsm" in C:\Mobius Reports
2. Update Outlook code (paste OutlookMonitor.txt into ThisOutlookSession)

That's it - all new features work automatically.

What's New:
- Total Portfolio Value now includes cash positions (USD, CAD, etc.)
- Total Portfolio Value now includes Options market value (was only showing P&L)
- Portfolio Allocation section now displays dollar signs on values

Support: Contact Jacob
