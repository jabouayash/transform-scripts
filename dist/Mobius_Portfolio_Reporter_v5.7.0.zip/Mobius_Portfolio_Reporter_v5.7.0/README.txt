MOBIUS PORTFOLIO REPORTER v5.7.0
================================

To Update:
1. Replace "Portfolio Transformer.xlsm" in C:\Mobius Reports
2. Update Outlook code (paste OutlookMonitor.txt into ThisOutlookSession)

That's it - all new features work automatically.

What's New in v5.7.0:
- YTD Return now shows correct official value (was showing ~2x actual)
- Chart labels no longer overlap with bars (improved readability)
- New Currencies tab for cash positions (USD, CAD, JPY, etc.)
- New Other tab for admin items (Accrued Dividends, Payables, etc.)
- Removed Fund Performance Summary section

Support: Contact Jacob
