# Email/WhatsApp Response Drafts

## Current Issue: Attachment Still Being Blocked

Google is still stripping the ZIP even with .bat renamed to .bat.txt.

### Response to Mark & Eric:

---

Thanks for letting me know. It looks like Google's security is still filtering the attachment.

Let me try sending it a different way. I'll follow up shortly.

---

## Options to Try:

1. **Double-zip** - Put the ZIP inside another ZIP
2. **Google Drive link** - Upload and share link (most reliable)
3. **Split the files** - Send PDF separately, then the rest

---

## Previous Responses:

### Explaining what the system does (to Mark):

Hey Mark, good question. This is separate from Bloomberg Terminal itself.

The ZIP is a file I attached to the email I just sent. It sets up a system on your computer that:
1. Watches your Outlook for the daily NAV report emails
2. Automatically transforms them into a portfolio view
3. Pulls live prices from Bloomberg (which runs in the background)

So your workflow stays the same: Bloomberg Terminal stays open as usual, the NAV emails come in, and the transformed report appears in a folder on your desktop. The setup is a one-time thing.

The PDF in the email has all the details, but please let me know if anything is unclear or if I can help clarify further.

---
