MOBIUS PORTFOLIO REPORTER v5.1
==============================

Quick Start:
1. Double-click INSTALL.bat (Run as Administrator if needed)
2. Follow the on-screen instructions
3. See docs/SETUP_GUIDE.md for Outlook setup

Files Included:
- INSTALL.bat              - Automated installer
- files/Portfolio Transformer.xlsm - Excel workbook with macros
- files/OutlookMonitor.txt - Code to paste into Outlook
- docs/SETUP_GUIDE.md      - Detailed setup instructions

Support: Contact Jacob
