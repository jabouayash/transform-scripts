MOBIUS PORTFOLIO REPORTER v5.7.2
================================

To Update:
1. Replace "Portfolio Transformer.xlsm" in C:\Mobius Reports
2. Update the macro inside (Alt+F11, paste TransformerMacro.txt)

That's it - all new features work automatically.

What's New in v5.7.2:
- Auto-email report to yourself after transformation completes
- Email sent to current Outlook user (no configuration needed)
- Email status shown in summary message ("Sent to..." or "Failed - reason")
- Set EMAIL_ENABLED = False in macro to disable

Support: Contact Jacob
