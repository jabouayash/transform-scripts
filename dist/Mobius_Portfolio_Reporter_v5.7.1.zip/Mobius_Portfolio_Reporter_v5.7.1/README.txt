MOBIUS PORTFOLIO REPORTER v5.7.1
================================

To Update:
1. Replace "Portfolio Transformer.xlsm" in C:\Mobius Reports
2. Update Outlook code (paste OutlookMonitor.txt into ThisOutlookSession)

That's it - all new features work automatically.

What's New in v5.7.1:
- Output file now opens automatically after transformation (no more hunting for file)
- Fixed distribution sync issue from v5.7.0

Support: Contact Jacob
