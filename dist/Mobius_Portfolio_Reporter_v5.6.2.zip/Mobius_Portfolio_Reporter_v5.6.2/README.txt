MOBIUS PORTFOLIO REPORTER v5.6.2
================================

To Update:
1. Replace "Portfolio Transformer.xlsm" in C:\Mobius Reports
2. Update Outlook code (paste OutlookMonitor.txt into ThisOutlookSession)

That's it - all new features work automatically.

What's New:
- Performance chart on Dashboard (shows portfolio value over time)
- No more popup when Outlook starts
- Processed files now move to Archive folder
- Cleaner layout (removed extra row from Stocks/Options tabs)

Support: Contact Jacob
